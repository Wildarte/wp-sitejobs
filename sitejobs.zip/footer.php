<footer class="footer">
        <div class="footer_content container">
            <h5>Sobre nós</h5>

     

            <?php

                wp_nav_menu([
                    'menu' => 'Menu Rodapé',
                    'theme_location' => 'menu-rodape',
                    'container' => false
                ]);

            ?>

        </div>
        <div class=" bottom_footer">
            <p>© 2022. Todos os direitos reservados</p>
        </div>
    </footer>


    <!-- wp footer -->
    <?php wp_footer() ?>
    <!-- wp footer -->
    <script>
        //url = <?= home_url() ?>;
        const bf = document.getElementById('send_apply');
        if(bf){
            bf.addEventListener('click', (e) => {
                e.preventDefault();
                sendForm('<?= get_template_directory_uri() ?>/submit_form.php');
            });
        }
    </script>

</body>
</html>