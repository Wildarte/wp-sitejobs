<?php

include('fieldspage/postfield.php');
include('fieldspage/fieldHome.php');